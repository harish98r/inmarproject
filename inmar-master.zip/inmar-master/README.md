Front end:HTML,CSS
Back end: PHP,SQL
Server:XAMPP(APACHE,MYSQL)


->Copy the file inmar pro into xampp>htdocs

->Import database.sql in phpmyadmin which creates the required tables and databases.
